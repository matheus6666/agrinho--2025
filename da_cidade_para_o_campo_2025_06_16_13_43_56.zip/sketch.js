let player;
let obstacles = [];
let groundY = 320;
let distanceFinal = 57600;
let celebration = false;
let celebrationParticles = [];
let totalTime = 120;
let startTime;
let speed = 4;
let cameraX = 0;

function setup() {
  createCanvas(800, 400);
  resetGame();
}

function draw() {
  let elapsed = (millis() - startTime) / 1000;
  let remaining = max(0, totalTime - floor(elapsed));

  background(135, 206, 235);
  cameraX = player.x - 100;

  drawBackground();

  // Timer
  let min = floor(remaining / 60);
  let sec = nf(remaining % 60, 2);
  fill(0);
  textSize(20);
  textAlign(RIGHT);
  text(`Tempo restante: ${min}:${sec}`, width - 10, 30);

  fill(100, 200, 100);
  rect(0, groundY, width, height - groundY);

  if (!celebration) {
    player.update();
    player.show();

    if (frameCount % 70 === 0) {
      let x = cameraX + width + random(100, 300);
      obstacles.push(new Obstacle(x));
    }

    for (let i = obstacles.length - 1; i >= 0; i--) {
      let obs = obstacles[i];
      obs.show();

      if (obs.hits(player)) {
        noLoop();
        textSize(40);
        fill(255, 0, 0);
        text("Game Over!", width / 2, 200);
        return;
      }

      if (obs.x + obs.w < cameraX) {
        obstacles.splice(i, 1);
      }
    }

    fill(0);
    textAlign(LEFT);
    text("Distância: " + floor(player.x) + "m", 10, 30);

    if (player.x > distanceFinal || remaining === 0) {
      celebration = true;
      for (let i = 0; i < 100; i++) {
        celebrationParticles.push(new CelebrationParticle());
      }
    }
  } else {
    fill(0, 150, 0);
    textSize(40);
    textAlign(CENTER);
    text("Você chegou ao sítio!", width / 2, 200);

    for (let p of celebrationParticles) {
      p.update();
      p.show();
    }
  }
}

function keyPressed() {
  if (key === ' ') {
    player.jump();
  } else if (key === 'r' || key === 'R') {
    resetGame();
  }
}

function resetGame() {
  player = new Player();
  obstacles = [];
  celebration = false;
  celebrationParticles = [];
  startTime = millis();
  speed = 4;
  loop();
}

class Player {
  constructor() {
    this.r = 40;
    this.x = 0;
    this.y = groundY - this.r;
    this.vy = 0;
    this.gravity = 1.1;
  }

  jump() {
    if (this.y === groundY - this.r) {
      this.vy = -17;
    }
  }

  update() {
    if (keyIsDown(87)) { // W
      speed += 0.1;
    }
    if (keyIsDown(83)) { // S
      speed -= 0.2;
    }
    speed = constrain(speed, 0, 10);
    this.x += speed;

    this.y += this.vy;
    this.vy += this.gravity;

    if (this.y > groundY - this.r) {
      this.y = groundY - this.r;
      this.vy = 0;
    }
  }

  show() {
    fill(50, 50, 200);
    let screenX = this.x - cameraX;
    rect(screenX, this.y, this.r, this.r);
    fill(255);
    ellipse(screenX + 10, this.y + this.r, 10, 10);
    ellipse(screenX + 30, this.y + this.r, 10, 10);
  }
}

class Obstacle {
  constructor(x) {
    this.types = ['fence', 'log', 'rock'];
    this.type = random(this.types);
    this.x = x;
    this.setTypeAttributes();
  }

  setTypeAttributes() {
    if (this.type === 'fence') {
      this.w = 30;
      this.h = 50;
      this.color = color(150, 75, 0);
    } else if (this.type === 'log') {
      this.w = 40;
      this.h = 30;
      this.color = color(120, 70, 20);
    } else if (this.type === 'rock') {
      this.w = 25;
      this.h = 25;
      this.color = color(100);
    }
    this.y = groundY - this.h;
  }

  show() {
    fill(this.color);
    let screenX = this.x - cameraX;
    rect(screenX, this.y, this.w, this.h, 5);
  }

  hits(player) {
    return (
      player.x + player.r > this.x &&
      player.x < this.x + this.w &&
      player.y + player.r > this.y
    );
  }
}

class CelebrationParticle {
  constructor() {
    this.x = random(width);
    this.y = random(-200, 0);
    this.speed = random(1, 4);
    this.size = random(16, 24);
    this.alpha = 255;
    this.color = color(random(100, 255), random(100, 255), random(100, 255));
  }

  update() {
    this.y += this.speed;
    this.alpha -= 0.5;
    if (this.y > height || this.alpha <= 0) {
      this.y = random(-200, 0);
      this.x = random(width);
      this.alpha = 255;
    }
  }

  show() {
    fill(this.color);
    textSize(this.size);
    textAlign(CENTER);
    push();
    translate(this.x, this.y);
    rotate(radians(random(-10, 10)));
    fill(this.color.levels[0], this.color.levels[1], this.color.levels[2], this.alpha);
    text("Parabéns!", 0, 0);
    pop();
  }
}

function drawBackground() {
  push();
  translate(-cameraX % width, 0);
  stroke(200);
  for (let x = -width; x < width * 2; x += 150) {
    let h = 50;
    let y = groundY - h - 20;
    fill(120, 120, 180);
    rect(x, y, 80, h);
  }
  pop();
}
